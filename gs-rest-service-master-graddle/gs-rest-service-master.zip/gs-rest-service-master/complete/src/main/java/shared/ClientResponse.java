package shared;

public class ClientResponse extends TimedResponse<ServerResponse> {
}
