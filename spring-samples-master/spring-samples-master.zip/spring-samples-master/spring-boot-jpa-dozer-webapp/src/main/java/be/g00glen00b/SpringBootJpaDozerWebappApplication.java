package be.g00glen00b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaDozerWebappApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootJpaDozerWebappApplication.class, args);
    }
}
