package be.g00glen00b.dto;

public enum SuperheroAlignmentDTO {
    GOOD, EVIL;
}
