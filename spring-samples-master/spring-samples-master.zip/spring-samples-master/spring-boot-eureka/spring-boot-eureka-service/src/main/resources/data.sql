DELETE FROM task;
INSERT INTO task (task, completed) VALUES
  ('My first task', true),
  ('My second task', false);