package be.g00glen00b.apps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSolrBatchApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootSolrBatchApplication.class, args);
    }
}
