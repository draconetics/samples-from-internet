(function(angular) {
  'use strict';

  angular.module('taskApp', ['ngResource', 'toastr']);

}(angular));