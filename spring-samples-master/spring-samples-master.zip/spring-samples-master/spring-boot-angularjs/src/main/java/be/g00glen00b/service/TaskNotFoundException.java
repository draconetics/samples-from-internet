package be.g00glen00b.service;

public class TaskNotFoundException extends RuntimeException {
}
