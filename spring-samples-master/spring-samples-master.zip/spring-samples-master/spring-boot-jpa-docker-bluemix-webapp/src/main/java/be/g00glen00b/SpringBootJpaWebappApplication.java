package be.g00glen00b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaWebappApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootJpaWebappApplication.class, args);
    }
}
