package be.g00glen00b.service;

import be.g00glen00b.entity.Superhero;

import java.util.List;

public interface SuperheroService {
    List<Superhero> findAll();
}
