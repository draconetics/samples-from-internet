package be.g00glen00b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebappApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWebappApplication.class, args);
    }
}
