package com.gp.model;

public enum Gender {

    MALE, FEMALE;

}
