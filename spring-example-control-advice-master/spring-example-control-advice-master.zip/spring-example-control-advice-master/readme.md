Example Spring ControlAdvice 
