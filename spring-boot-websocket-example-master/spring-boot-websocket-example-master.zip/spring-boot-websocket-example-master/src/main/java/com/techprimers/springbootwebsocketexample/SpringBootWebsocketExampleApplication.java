package com.techprimers.springbootwebsocketexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebsocketExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebsocketExampleApplication.class, args);
	}
}
