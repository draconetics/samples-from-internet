# WebSockets in a Spring Boot Application

- `/app/user` - Message Mapping URL
- `/topic/user` - Message Broker topic for pushing messages to the UI back.
 