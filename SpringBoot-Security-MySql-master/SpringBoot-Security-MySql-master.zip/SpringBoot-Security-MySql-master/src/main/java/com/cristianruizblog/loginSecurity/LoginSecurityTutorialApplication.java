package com.cristianruizblog.loginSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginSecurityTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginSecurityTutorialApplication.class, args);
	}
}
