package com.innova.spring.boot.soap.mtomresponse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapMtomResponseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapMtomResponseApplication.class, args);
	}
}
