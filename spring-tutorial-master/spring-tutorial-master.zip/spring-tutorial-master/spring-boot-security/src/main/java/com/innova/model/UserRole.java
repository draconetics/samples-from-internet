package com.innova.model;

public enum UserRole {

    ADMIN, USER
}
