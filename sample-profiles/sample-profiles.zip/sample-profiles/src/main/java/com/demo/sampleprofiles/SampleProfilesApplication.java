package com.demo.sampleprofiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleProfilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleProfilesApplication.class, args);
	}

}
